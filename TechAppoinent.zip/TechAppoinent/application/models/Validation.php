<?php

   /**
    * 
    */
   class Validation extends CI_Model
   {
   	
   	public function login_all($username, $password, $user_role_id){
   	   $query = $this->db->where(['username'=>$username, 'password'=>$password, 'user_role_id'=>$user_role_id])->get('user');

              if($query->num_rows() > 0){
                  return $query->row()->user_id;
              }
   	} 
    public function getAdminList(){ // view all admin in Super admin

             $this->db->select(['user.user_id','user.name','user.username','user_role.role_name','user.mobile']);
               $this->db->from('user');
               $this->db->join('user_role','user_role.id = user.user_role_id');
               $this->db->where(['user.user_role_id' => '1']);
               $query = $this->db->get();
              return $query->result();
      }

      public function getIncubeList(){ // view all INcube in Super admin

             $this->db->select(['user.user_id','user.name','user.username','user_role.role_name','user.mobile']);
               $this->db->from('user');
               $this->db->join('user_role','user_role.id = user.user_role_id');
               $this->db->where(['user.user_role_id' => '4']);
               $query = $this->db->get();
              return $query->result();
      }

      public function getAdminList_C(){ // view all admin in Super admin COntact

             $this->db->select(['user.user_id','user.name','user.username','user_role.role_name','user.mobile']);
               $this->db->from('user');
               $this->db->join('user_role','user_role.id = user.user_role_id');
               $this->db->where(['user.user_role_id' => '1']);
               $query = $this->db->get();
              return $query->result();
      }

    public function getUserList(){ // view all User in Super admin

             $this->db->select(['user.user_id','user.name','user.mobile','user.username','user_role.role_name']);
               $this->db->from('user');
               $this->db->join('user_role','user_role.id = user.user_role_id');
               $this->db->where(['user.user_role_id' => '2']);
               $query = $this->db->get();
              return $query->result();
      }

      public function addAdmin($data){       // add admin by super admin panel
           return $this->db->insert('user',$data);
      }

       public function Feedback($data){       // Feedback form
           return $this->db->insert('feedback',$data);
      }
       public function addUser($data){       // add admin by super admin panel
           return $this->db->insert('user',$data);
      }

      public function getAdminRole(){

             $query = $this->db->where(['role_name'=>'Admin_Create'])->get('user_role');
               if($query->num_rows() > 0){
                    return $query->row()->id;
               }
      }
      public function getUserRole(){
             $query = $this->db->where(['role_name'=>'User_Create'])->get('user_role');
               if($query->num_rows() > 0){
                    return $query->row()->id;
               }
      }

       public function insertAdminpersonalDetail($data){ 
           return $this->db->insert('admin_personal_detail', $data);
           }//insert adminPersonal detail query

          public function insertAdminContact_Detail($data){
          return $this->db->update('admin_personal_detail', $data);
        }//Update contact adminPersonal detail query
    

       public function getAdminRecords($admin_id){
          $query = $this->db->where(['user_id' => $admin_id])->get('user'); // admin record view
             if($query->num_rows() > 0){                                    // Super admin
                return $query->row();
            }
      }

       public function get_num_rows(){
          $query = $this->db->get('user');
           return $query->num_rows();
      }

      public function userRequerst(){     //Admin view who send appoinment admin dashboard

            $this->db->select(['user_appoint.id','user_appoint.name','user_appoint.email','user_appoint.mobile','user_appoint.subject','user_appoint.description','user_appoint.status']);
            $this->db->from('user_appoint');
            $query = $this->db->get();
            return $query->result();

             return $this->db->update('user_appoint', $data);
      }

      public function insertRespone($data){
          return $this->db->update('user_appoint', $data);
        }//Update contact adminPersonal detail query

         public function responeadmin(){

           $this->db->select(['user_appoint.name','user_appoint.mobile','user_appoint.subject','user_appoint.description','user_appoint.status']);
           $this->db->from('user_appoint');
           $query = $this->db->get();
           return $query->result();
      }

      public function viewappoinStatus(){

           $this->db->select(['user_appoint.user_id','user_appoint.name','user_appoint.status','user_appoint.time','user_appoint.location']);
           $this->db->from('user_appoint');
           $query = $this->db->get();
           return $query->result();
      }

      public function AppoinmentForm($admin_id){    // appoinment form 
            $query = $this->db->where(['user_id' => $admin_id])->get('user'); 
             if($query->num_rows() > 0){                                 
                return $query->row();
               }
      }

      public function AppoinmentAdd($data){    // appoinment add in user dashboard
           return $this->db->insert('user_appoint',$data);
  
      }

     public function viewDetail(){     //Admin view in USer

            $this->db->select(['admin_personal_detail.first_name','admin_personal_detail.last_name','admin_personal_detail.username','admin_personal_detail.nationality','admin_personal_detail.designation','admin_personal_detail.company','admin_personal_detail.Work_ex','admin_personal_detail.mobile','admin_personal_detail.work_loca','admin_personal_detail.address']);
            $this->db->from('admin_personal_detail');
            $query = $this->db->get();
            return $query->result();
      }

   }
?>