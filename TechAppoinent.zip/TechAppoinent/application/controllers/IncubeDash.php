<?php

 /**
  * 
  */
 class IncubeDash extends CI_Controller
 {
 	
     public function index()
      {
           $this->load->view('incube/Dasboard'); 
       
       }// Dashboard of incubeety---------------------------

     public function Gallery()
     {
     	$this->load->view('incube/Gallery');
     }
 	  
 	 
     
     public function About(){
        
         $this->load->view('incube/About');
     }
         
         public function feedback_Add($admin_id){
             $this->form_validation->set_rules('name','Name','required');
             $this->form_validation->set_rules('email','Email','required');
             $this->form_validation->set_rules('mob','Mobile','required');
             $this->form_validation->set_rules('descrip','Description','required');
             $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
                   if( $this->form_validation->run() ){
                         $data = $this->input->post();
                         $this->load->model('Validation');
                    if($this->Validation->Feedback($data)){
                           $this->session->set_flashdata('Done',' Done Successfully!!!!');
                      }else{
                           $this->session->set_flashdata('Done','Failled!!!!');
                      }
                           return redirect('IncubeDash');
                        }
                 else{
                      $this->load->view('incube/About');
                 }
   }
       
   
 }
?>

