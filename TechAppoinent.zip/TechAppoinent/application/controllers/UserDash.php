<?php

    /**
     * 
     */
    class UserDash extends CI_Controller
    {
    	
    	 public function index(){
         if(!$this->session->userdata('user_id')){     // userDashboard code
             return redirect('login');
         }else{
              
              $this->load->view('User/Dashboard');

           }
     }

       public function viewAppoinRes()
       {
              $this->load->model('Validation');
              $result = $this->Validation->viewappoinStatus(); 
                //view and reciev all admin in user panel
              $this->load->view('User/viewAppoinRes',['result'=>$result]);
       }

        public function viewAdmin_U(){
        $this->load->model('Validation');
        $result = $this->Validation->getAdminList();
        $this->load->view('User/viewAdmin_U',['result' => $result]);
         }// admin list in super admin 

    
   public function viewDetail_U($admin_id){

           $this->load->model('Validation');
            $result = $this->Validation->viewDetail($admin_id);
           $this->load->view('User/viewDetail_U',['result' => $result]);
       }

     //  User appoinment form to appoint for admin
     
     public function addAppoin_U($admin_id){
         $this->load->model('Validation');
         $result = $this->Validation->AppoinmentForm($admin_id);
         $this->load->view('User/addAppoin_U',['result' => $result]);
     }
         
         public function insertAppoinment_form($admin_id){
             $this->form_validation->set_rules('name','Name','required');
             $this->form_validation->set_rules('email','Email','required');
             $this->form_validation->set_rules('mobile','Mobile','required');
             $this->form_validation->set_rules('subject','Subject','required');
             $this->form_validation->set_rules('description','Description','required');
             $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
                   if( $this->form_validation->run() ){
                         $data = $this->input->post();
                         $this->load->model('Validation');
                    if($this->Validation->AppoinmentAdd($data)){
                           $this->session->set_flashdata('Appoinment_done','Appoinment Done Successfully!!!!');
                      }else{
                           $this->session->set_flashdata('Appoinment_done','Failled!!!!');
                      }
                           return redirect('UserDash');
                        }
                 else{
                      $this->load->view('User/addAppoin_U');
                 }
   }



    }
 ?>