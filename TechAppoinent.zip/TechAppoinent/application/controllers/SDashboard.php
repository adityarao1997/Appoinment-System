<?php

  /**
   * 
   */
  class SDashboard extends CI_Controller
  {
  	
  	public function index(){
  		
  	if(!$this->session->userdata('user_id')){
                    return redirect('login');
                }else{
                 
                 
                   $this->load->view('superA/dashboard');

                }

          }

     public function admin_C()
     { 
          $this->load->model('Validation');
          $result = $this->Validation->getAdminList_C();
          $this->load->view('superA/admin_C',['result' => $result]);
      }

      public function ViewAdmic_C()
      {
          $this->load->model('Validation');
          $result = $this->Validation->viewDetail();
         $this->load->view('superA/ViewAdmic_C',['result' => $result]);
      }


    public function viewadminS(){
        $this->load->model('Validation');
        $result = $this->Validation->getAdminList();
        $this->load->view('superA/Viewadmin_S',['result' => $result]);
    }// admin list in super admin 

     public function incube_S(){
        $this->load->model('Validation');
        $result = $this->Validation->getIncubeList();
        $this->load->view('superA/incube_S',['result' => $result]);
     }// admin list in super admin 

    public function viewUserS(){
        $this->load->model('Validation');
        $result = $this->Validation->getUserList();
        $this->load->view('superA/ViewUser_S',['result' => $result]);
    }// User list in super admin 

     public function adminadd_S(){
             $this->load->model('Validation');
             $result = $this->Validation->getAdminRole();
             $this->load->view('superA/adminadd_S',['result' => $result]);
         }
       public function insertadmin(){
            $this->form_validation->set_rules('name','Name','required');
            $this->form_validation->set_rules('mobile','mobile','required');
           $this->form_validation->set_rules('username','Username','required');
           $this->form_validation->set_rules('password','Password','required');
           $this->form_validation->set_rules('user_role_id','User_Role','required');
           $this->form_validation->set_rules('terms','terms','required');
           $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
             if( $this->form_validation->run() ){

                   $data = $this->input->post();
                   $this->load->model('Validation');
                     if($this->Validation->addAdmin($data)){
                         $this->session->set_flashdata('admin_add','User Add Successfully!!!!');
                      }else{
                         $this->session->set_flashdata('admin_add','Failled!!!!');
                     }
                        return redirect('SDashboard');
                    }
             else{
                 $this->load->view('superA/adminadd_S');
             }
   }

        
    //Super admin fill detail on admin personal detail and view-------------
    
            public function adminPersonalDetail_S($admin_id){
            $this->load->model('Validation');
            $result = $this->Validation->getAdminRecords($admin_id);
            $this->load->view('superA/adminPersonalDetail_S',['result'=> $result]);
        }

        public function addPersonalDetail($admin_id){

          $this->form_validation->set_rules('user_role_id','user_role_id','required');
          $this->form_validation->set_rules('first_name','First Name','required');
          $this->form_validation->set_rules('last_name','Last Name','required');
          $this->form_validation->set_rules('username','Username','required');
          $this  ->form_validation->set_rules('gender','Gender','required');
          $this->form_validation->set_rules('nationality','Nationality','required');
          $this->form_validation->set_rules('marrige_status','Married Status','required');
          $this->form_validation->set_rules('dob','DoB','required');
          // $this->form_validation->set_rules('avtar','Profile Image','required');
         $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
                if( $this->form_validation->run()){

                      $data = $this->input->post();
                      $this->load->model('Validation');

                         if($this->Validation->insertAdminpersonalDetail($data)){
                             $this->session->flashdata('admin_add','Admin add Successfully');

                          }else{
                          $this->session->flashdata('admin_add','Faild To admin Successfully');
                      }
                    $this->adminContactDetail_S($admin_id);
                }else{

                        return redirect('adminPersonalDetail_S');
                }
        }

//---------------Contact admin details     ----------------------


            public function adminContactDetail_S($admin_id){

               $this->load->model('Validation');
                $result = $this->Validation->getAdminRecords($admin_id);
           $this->load->view('superA/adminContactDetail_S',['result'=> $result]);
                }
 
                    public function addContact_detail($admin_id){

          $this->form_validation->set_rules('designation','designation','required');
          $this->form_validation->set_rules('company','company Name','required');
          $this->form_validation->set_rules('Work_ex','Work_ex','required');
          $this->form_validation->set_rules('mobile','mobile','required');
          $this->form_validation->set_rules('phone','phone','required');
          $this->form_validation->set_rules('address','address','required');
          $this->form_validation->set_rules('work_loca','work_loca Status','required');
         
          $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
                if( $this->form_validation->run()){

                      $data = $this->input->post();
                      $this->load->model('Validation');

                         if($this->Validation->insertAdminContact_Detail($data)){
                             $this->session->flashdata('admin_add','Admin add Successfully');

                          }else{
                          $this->session->flashdata('admin_add','Faild To admin Successfully');
                      }
                        return redirect('SDashboard');
                }else{

                    $this->adminContact_detail($admin_id);
                }
        }

       
    
  }
?>