<?php

 class Login extends CI_Controller
 {
 	
 	public function index()
 	{
 		      $this->load->view('layout/login');
 	}

 	public function all_login(){
 		$this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('user_role_id', 'user_role_id', 'required');
       $this->form_validation->set_error_delimiters('<div class="error">','</div>');
                 if($this->form_validation->run()){

                    $username = $this->input->post('username');
                    $password = $this->input->post('password');
                    $user_role_id = $this->input->post('user_role_id');
                    $this->load->model('Validation');
                    $user_id = $this->Validation->login_all($username, $password, $user_role_id);
                      if($user_id > 0){
                          $this->session->set_userdata(['user_id'=>$user_id]);
                          if($user_role_id == '3'){
                  
                             return redirect('SDashboard');
                            
                          }else{
                             if($user_role_id =='2'){
                          
                                return redirect('UserDash');
                              } else{
                                 if($user_role_id == '1'){
                                    
                                     return redirect('AdminDash');
                                  }else{
                                    if ($user_role_id == '4') {
                                      return redirect ('IncubeDash');
                                    }
                                  }
                              }
                          }
                      }else{
                         $error = $this->session->set_flashdata('login_response', 'Invalid username/password');
                           return redirect($this->$config['base_url']);
                         ;
                      }
             }else{
                 $this->load->view('layout/login');
             }
 	}

      public function Registration(){

        $this->load->model('Validation');
           $result = $this->Validation->getUserRole();
           $this->load->view('layout/register',['result' => $result]);

      }
       public function insertuser(){
           $this->form_validation->set_rules('name','Name','required');
           $this->form_validation->set_rules('username','Username','required');
           $this->form_validation->set_rules('mobile','Username','required');
           $this->form_validation->set_rules('password','Password','required');
           $this->form_validation->set_rules('user_role_id','User_Role','required');
           $this->form_validation->set_rules('terms','terms','required');
           $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
             if( $this->form_validation->run() ){

                   $data = $this->input->post();
                   $this->load->model('Validation');
                     if($this->Validation->addUser($data)){
                         $this->session->set_flashdata('User_add','User Add Successfully!!!!');
                      }else{
                         $this->session->set_flashdata('User_add','Failled!!!!');
                     }
                        return redirect('Login');
                    }
             else{
                 $this->load->view('layout/register');
             }
         }

           public function logout(){
           $this->session->unset_userdata('user_id');
           $this->load->view('layout/login');
       }
 }

?>