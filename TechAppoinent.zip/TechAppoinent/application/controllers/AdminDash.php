<?php

/**
 * 
 */
class AdminDash extends CI_Controller
{
	

	 public function index(){
       if(!$this->session->userdata('user_id')){
           return redirect('login');
       }else{                                // admin login dashboards
            
            $this->load->view('Admin/Dashboard');

         }
   }

   public function viewUser_A(){
     	$this->load->model('Validation');
        $result = $this->Validation->getUserList();
        $this->load->view('Admin/viewUser_A',['result' => $result]);
   }

   public function viewAppoin_A(){
  
              $this->load->model('validation');
              $result = $this->validation->userRequerst();
              $this->load->view('Admin/viewAppoin_A',['result' => $result]);
       
   }

   public function Respone_A(){
               $this->load->model('validation');
              $result = $this->validation->responeadmin();
              $this->load->view("Admin/Respone_A",['result' => $result]);
   }

    public function addRespone(){
          $this->form_validation->set_rules('status','status','required');
          $this->form_validation->set_rules('time','time','required');
          $this->form_validation->set_rules('location','location','required');
          
          $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
                if( $this->form_validation->run()){

                      $data = $this->input->post();
                      $this->load->model('validation');
                         if($this->validation->insertRespone($data)){
                             $this->session->flashdata('admin_add','Admin add Successfully');
                          }else{
                          $this->session->flashdata('admin_add','Faild To admin Successfully');
                      }
                        return redirect('AdminDash/viewAppoin_A');
                }else{

                    $this->Admindashboard();
                }
        }
    
    public function Calender_A(){
        
        $this->load->view('Admin/Calender_A');
    }

}
?>