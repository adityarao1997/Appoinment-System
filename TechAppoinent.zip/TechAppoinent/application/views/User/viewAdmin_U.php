<?php 

    $this->load->view('User/include/header');
    $this->load->view('User/include/sidebar');
    $this->load->view('User/include/viewAdminMain_U');
    $this->load->view('User/include/footer');


?>






