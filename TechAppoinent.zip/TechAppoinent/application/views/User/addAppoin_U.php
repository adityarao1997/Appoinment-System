<?php 

    $this->load->view('User/include/header');
    $this->load->view('User/include/sidebar');
    $this->load->view('User/include/addAppoinMain_U');
    $this->load->view('User/include/footer');


?>






