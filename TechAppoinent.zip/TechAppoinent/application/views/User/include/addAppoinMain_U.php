<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Fixed Navbar Layout</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="">
  <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Appoinment</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">Admin List</li>
              <li class="breadcrumb-item">Appoinment</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="col-lg-12 connectedSortable ml-5">
     
     <?php echo form_open_multipart("userdash/insertAppoinment_form/{$result->user_id}"); ?>
      <?php echo form_hidden('user_id', $result->user_id); ?>      

<legend style="text-align: center;"><font color="black"><b><hr>Appoinment Form </b><hr></legend>

<div class="row">
<div class="container" >
  

<div class="col-lg-8" style="border: 1px solid black; margin-left: 20%; background-color: grey; shadow: 2px 2px;">
<?php echo form_open("userdash/insertAppoinment_form");?>
 
  <fieldset>
      <br>
      <?php if( $error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-6">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
      <?php endif; ?>

      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <font color="black"><b><label for="exampleInputEmail1">Name</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'name','class'=>'form-control', 'placeholder'=>' Name','value'=>set_value('name')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
          <?php echo form_error('Name','<div class="text-danger">','</div>');?>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Email address :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'email','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('email')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Mobile Number :</label>
            <div class="col-lg-8">
            <?php echo form_input(['name' => 'mobile','class'=>'form-control', 'placeholder'=>'Mobile','value'=>set_value('mobile')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
          <?php echo form_error('mobile','<div class="text-danger">','</div>');?>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Subject</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'subject','class'=>'form-control', 'placeholder'=>'Subject ','value'=>set_value('subject')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
          <div class="form-group">
              <label for="inputEmail" class="col-lg-4 control-label">Description :</label>
                <div class="col-lg-8">
                 <?php echo form_textarea(['name' => 'description','class'=>'form-control', 'row' =>'4', 'placeholder'=>'description ','value'=>set_value('description')])?>
                </div>
          </div>
        </div>
    </div>

      <div class="container col-lg-10">
          <?php echo form_submit(['value' => 'Submit','class'=>'btn btn-primary'])?>
          <?php echo form_reset(['value' => 'Reset','class'=>'btn btn-secondary'])?>
      </div><br><br>

  </fieldset>
<?php echo form_close();?>
</div>
</div>
    </div>
    </section>      
  </div>
</body>
</html>