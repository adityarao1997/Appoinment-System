<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Fixed Navbar Layout</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="">


  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">User Panel</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">View Respone</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
 
          <section class="col-lg-12 connectedSortable">
           
   <legend style="text-align: center;"><b><hr> View Respone </b><hr></legend>
 <div class="container">
    <div class="col-lg-8">
        
   <?php echo form_close();?>
    </div><br><br>

     <table class="table table-hover table-active">
 <thead>
   <tr style="background-color: #007bff; color: white;">
     <th scope="col">Admin Id.</th>
     <th scope="col">Name</th>
     <th scope="col">Status</th>
    <th scope="col">Time</th>
    <th scope="col">location</th>
   </tr>
 </thead>
 <tbody>
     <?php if(count($result)): ?>
       <?php foreach($result as $res):?>
          <tr style="background-color: white">
               <td ><?php echo $res->user_id; ?></td>
               <td><?php echo $res->name; ?></td>
                 <?php if($res->status == '0'): ?>
                     <td style="color: blue;"><?php echo "pendding"; ?></td>
                  <?php else: ?>
                  <?php if($res->status == '1'): ?>
                  <td style="color: green;"><?php echo "Done"; ?></td>
                  <?php else: ?>
                    <?php if($res->status == '2'): ?>
                  <td style="color: red;"><?php echo "Declien"; ?></td>
                   <?php endif;?>
                   <?php endif;?>
               <td><?php echo $res->time; ?></td>
               <td><?php echo $res->location; ?></td>
               <?php endif;?>

         </tr>
      <?php endforeach; ?>
       <?php else: ?>
         <tr>
            <td>No record Found!!</td>
         </tr>
    <?php endif; ?>
</tbody>
</table>

   </div>
 </div>
<br>


        
         </section>
            
</div>
</body>
</html>