<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Fixed Navbar Layout</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="">


 
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">User Panel</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
  
       
          <section class="col-lg-12 connectedSortable">
           
           
    <div class="row">
       <div class="col-lg-12">
          <legend><b>Personal Details Admin</b></legend><hr>
           <div class="row">
<div class="container">
<?php echo form_open("Userdash/viewDetail_U");?>
  <fieldset>
      
   
<div class="col-lg-12"><br>
   <table class="table table-hover table-active table-info" style="background-color: white;">
      <th scope="col" style="color: white; background-color: #007bff;">Option</th>
      <th scope="col" style="color: white; background-color: #007bff;">Details</th>         
        <?php if(count($result)): ?>
        <?php foreach($result as $res):?>   
         
         <tr >
              <th>First Name:</th>
              <td><?php echo $res->first_name; ?></td>
          </tr>
          <tr>
             <th>Last Name:</th>
             <td><?php echo $res->last_name; ?></td>
          </tr>
          <tr>
             <th>Designation:</th>
             <td><?php echo $res->designation; ?></td>
          </tr>
           <tr>
             <th>Company:</th>
             <td><?php echo $res->company; ?></td>
          </tr>
           <tr>
             <th>Work Experience:</th>
             <td><?php echo $res->Work_ex; ?></td>
          </tr>
           <tr>
             <th>Telephone:</th>
             <td><?php echo $res->mobile; ?></td>
          </tr>
           <tr>
             <th>Location:</th>
             <td><?php echo $res->work_loca; ?></td>
          </tr>

 <?php endforeach; ?>
  <?php else: ?>
          <tr>
             <th>No record Found!!</th>
          </tr>
<?php endif; ?>
</table>
   <hr> 
</div>
     

  </fieldset>
<?php echo form_close();?>
</div>
</div>
       </div>
    </div>
  </div>
        
         </section>
            

</body>
</html>