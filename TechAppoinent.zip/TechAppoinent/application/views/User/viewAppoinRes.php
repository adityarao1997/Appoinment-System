<?php 

    $this->load->view('User/include/header');
    $this->load->view('User/include/sidebar');
    $this->load->view('User/include/ViewAppoinMain_U');
    $this->load->view('User/include/footer');


?>