<?php 

    $this->load->view('Admin/include/header');
    $this->load->view('Admin/include/sidebar');
    $this->load->view('Admin/include/ViewAppoinMain_A');
    $this->load->view('Admin/include/footer');


?>