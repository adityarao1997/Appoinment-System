
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="">
  <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">View Admin</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">Super Admin</li>
              <li class="breadcrumb-item">View Admin</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="col-lg-12 connectedSortable">
      <div class="container">
     <?php echo form_open_multipart("AdminDash/addRespone"); ?>
    <div class="row">
       <div class="col-lg-6">
          <legend><b>Personal Details Admin</b></legend><hr>
            <?php echo form_open("admin/respone");?>
<fieldset>   
  <div class="col-lg-12" ><br>
   <table class="table table-hover table-active table-info" style="background-color: white;">
      <th scope="col" style="color: white; background-color: #007bff;">Option</th>
      <th scope="col" style="color: white; background-color: #007bff;">Details</th>         
        <?php if(count($result)): ?>
        <?php foreach($result as $res):?>   
         <tr >
              <th> Name:</th>
              <td><?php echo $res->name; ?></td>
          </tr>
          <tr>
             <th>Mobile :</th>
             <td><?php echo $res->mobile; ?></td>
          </tr>
           <tr>
             <th>Subject:</th>
             <td><?php echo $res->subject; ?></td>
          </tr>
           <tr>
             <th>Description :</th>
             <td><?php echo $res->description; ?></td>
          </tr>
           

 <?php endforeach; ?>
  <?php else: ?>
          <tr>
             <th>No record Found!!</th>
          </tr>
<?php endif; ?>
</table>
 
</div>
     

  </fieldset>

    </div>
    <div class="col-lg-6">
       <legend> Edit work</legend><hr>
       <div class="col-lg-12"><br>
        <table class="table table-hover table-active table-info" style="background-color: white;">
           <th scope="col" style="color: white; background-color:  #007bff;">Detail</th>
            <th scope="col" style="color: white; background-color: #007bff;">Edit</th>
                <tr>
                  <th >Status :</th>
                  <td>
                   <div class="col-lg-12">
                     <select class="form-control" name="status">
                       <option>Select</option>
                       <option value="1">Accept</option>
                       <option value="2">Decline</option>
                     </select>
                   </div>
                  </td>
                </tr>
                <tr>
                  <th >Date&time :</th>
                   <td>
                        <div class="col-lg-10">
                           <?php echo form_input(['name' => 'time','class'=>'form-control', 'id'=>'datepicker','placeholder'=>'yyyy-mm-dd hh:ii','value'=>set_value('time')])?>
                        </div>
                    </td>
                </tr>
                <tr>
                  <th> Location : </th>
                  <td>
                    <div class="col-lg-12" style="">
                      <?php echo form_input(['name' => 'location','class'=>'form-control', 'placeholder'=>'Location','value'=>set_value('location')])?>
             </div>
                  </td>
                </tr>
            </table> 
       </div><br><br>
        <div class="container" style="margin-left: 70%; ">
          <?php echo form_submit(['value' =>'Submit','class'=>'btn btn-info '])?>
          
      </div>
  </div>

  <?php echo form_close();?>
</div>

    </section>      
  </div>
</body> 
</html>