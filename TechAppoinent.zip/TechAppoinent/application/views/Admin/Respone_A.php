<?php 

    $this->load->view('Admin/include/header');
    $this->load->view('Admin/include/sidebar');
    $this->load->view('Admin/include/ResponeMain_A');
    $this->load->view('Admin/include/footer');


?>