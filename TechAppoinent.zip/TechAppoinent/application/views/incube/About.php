
<?php 

    $this->load->view('incube/include/header');
    $this->load->view('incube/include/sidebar');
    $this->load->view('incube/include/about_Inc');
    $this->load->view('incube/include/footer');
?>
