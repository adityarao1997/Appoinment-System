
<?php 

    $this->load->view('superA/include/header');
    $this->load->view('superA/include/sidebar');
    $this->load->view('superA/include/adminMain_C');
    $this->load->view('superA/include/footer');


?>
