<?php 

    $this->load->view('superA/include/header');
    $this->load->view('superA/include/sidebar');
    $this->load->view('superA/include/incubeMain_S');
    $this->load->view('superA/include/footer');


?>
