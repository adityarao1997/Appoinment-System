<?php 

    $this->load->view('superA/include/header');
    $this->load->view('superA/include/sidebar');
    $this->load->view('superA/include/adminPersonalDetailMain_S');
    $this->load->view('superA/include/footer');


?>

