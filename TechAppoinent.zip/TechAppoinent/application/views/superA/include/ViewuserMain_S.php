
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="">
  <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">View User</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">Super Admin</li>
              <li class="breadcrumb-item">View User</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="col-lg-12 connectedSortable">
      <div class="Container col-md-12">
         <?php echo form_open("dashboard/search" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <div class="form-group col-md-4 ">
            <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('username')]);?>
         </div>
         <div class="form-group col-md-4">
            <?php echo form_submit(['value' => 'search','class'=>'btn btn-primary']);?>
        </div>
        <div class="form-group col-md-4"> 
               <?php echo anchor("admin/deleteadmin",'Delete',['class'=>'btn btn-danger']);?>
        </div>       
         <?php echo form_close();?>
     </div>
     <?php if( $error = $this->session->flashdata('admin_add')): ?>
     <div class="row">
         <div class="col-lg-10">
           <div class="alert alert-dismissible alert-success">
               <button type="button" class="close" data-dismiss="alert">&times;</button>
               <strong>Well done!</strong> You successfully Add <a href="#" class="alert-link">this New Admin</a>.
           </div>
         </div>
     </div>
      <?php endif; ?>
     <?php if( $error = $this->session->flashdata('admin_add')): ?>
     <div class="row">
         <div class="col-lg-10">
           <div class="alert alert-dismissible alert-success">
               <button type="button" class="close" data-dismiss="alert">&times;</button>
               <strong>Well done!</strong> You successfully Add <a href="#" class="alert-link">this New Admin</a>.
           </div>
         </div>
     </div>
    <?php endif; ?>
      <table class="table table-hover table-active">
  <thead>
    <tr>
      <th scope="col">Check Box</th>
      
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Designation</th>
      <th scope="col">Mobile</th>
      <th scope="col">Role ID</th>
      <th scope="col">Role ID</th>
    </tr>
  </thead>
  <tbody>
      <?php if(count($result)): ?>  
        <?php foreach($result as $res):?>
           <tr class="table-success">
               <?php if($res->user_id == 3): ?>
                  <td></td>
               <?php endif; ?>
               <?php if($res->user_id == 3): ?>
                  <td><?php echo $res->name; ?></td>
               <?php else: ?>
                 <th><?php echo form_checkbox(['class'=>'checkbox']);?></th>
                <td><?php echo $res->name; ?></td>
            <?php endif; ?>    
                <td><?php echo $res->username; ?></td>
                <td><?php echo $res->role_name; ?></td> 
                <td><?php echo $res->mobile; ?></td> 
                <td><?php echo $res->role_name; ?></td>
                <td><?php echo $res->role_name; ?></td>
          </tr>
       <?php endforeach; ?>
        <?php else: ?>
          <tr>
             <td>No record Found!!</td>
          </tr>
     <?php endif; ?>
 </tbody>
</table> 
    </section>      
  </div>
</body> 
</html>