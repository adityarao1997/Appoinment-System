
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4" style="height: auto;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link elevation-4 mr-1">
      <img src="<?php echo base_url('assets/dist/img/tech.png');?>"
           alt="AdminLTE Logo"
           class="brand-image elevation-21"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><b>Appoinment</b></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar ">
      <!-- Sidebar user (optional) -->
      <div class="user-panel d-flex">
      </div>

      <!-- Sidebar Menu --><br>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column " data-widget="treeview" role="menu" data-accordion="false" role="menu" data-accordion="false">
                        <!-- Dashboard Menu -->
             <li class="nav-item has-treeview nav-link active">
               <a class="">
                 <?php echo anchor('SDashboard','<i class="nav-icon fas fa-tachometer-alt"></i><p class="hidden-tablet">Dashboard </p>')?>
               </a>
             </li>
                        <!-- Super Admin Menu -->
              <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('SDashboard/admin_C','<i class="nav-icon fas fa-user-shield text-danger"></i><p class="hidden-tablet"> Admin Contact </p>','class = nav-link')?>
               </a>
             </li>
                         <!-- Admin Menu -->
              <li class="nav-item has-treeview ">
               <a class="">
                <?php echo anchor('SDashboard/viewadminS','<i class="nav-icon fas fa-user-shield text-warning"></i><p class="hidden-tablet"> Admin List </p>','class = nav-link')?>
               </a>
             </li>
                          <!-- USer Menu -->
              <li class="nav-item has-treeview">
               <a  class="">
              <?php echo anchor('SDashboard/viewUserS','<i class="nav-icon fas fa-user-tie"></i><p class="hidden-tablet"> User List </p>','class = nav-link')?>
               </a>
             </li>
                  <!-- Admin Add Menu -->
             <li class="nav-item has-treeview">
              <a  class="">
                <?php echo anchor('SDashboard/adminadd_S','<i class="nav-icon fas fa-user-plus"></i><p class="hidden-tablet"> Add Admin </p>','class = nav-link')?>
               </a> 
            </li>

            <li class="nav-item has-treeview">
              <a  class="">
                <?php echo anchor('SDashboard/incube_S','<i class="nav-icon fas fa-user-check text-info"></i><p class="hidden-tablet"> View  Incube </p>','class = nav-link')?>
               </a> 
            </li><i class=""></i>
                         <!-- Dashboard Menu -->
              <li class="nav-item has-treeview">
               <a href="#" class="nav-link">
                 <i class="nav-icon fas fa-book"></i>
                <p>Appoinment Detail</p>
                <i class="right fas fa-angle-left"></i>
               </a>
               <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon text-info"></i>
                  <p>Appoinmet List</p>
                </a>
              </li>
            </ul>
               <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon text-warning"></i>
                  <p>Pendding List</p>
                </a>
                </li>
            </ul>
               <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon  text-danger"></i>
                  <p>Declien List</p>
                </a>
             </li>
            </ul>
         </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Pages
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../examples/invoice.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Invoice</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../examples/profile.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Profile</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../examples/e_commerce.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>E-commerce</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../examples/projects.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Projects</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../examples/project_add.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Project Add</p>
                </a>
              </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
  </aside>
    <!-- /.sidebar -->