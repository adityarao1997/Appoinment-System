
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body>

   <div class="content-wrapper"> 
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Admin Personal Detail</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">View Admin</li>
              <li class="breadcrumb-item">Admin Detail</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <?php echo form_open_multipart("SDashboard/addPersonalDetail/{$result->user_id}"); ?>
      <?php echo form_hidden('user_id', $result->user_id); ?>
     <section class="col-lg-12 connectedSortable"> 

     
  <div class="container">
  <?php echo form_open_multipart("admin/addPersonalDetail/{$result->user_id}"); ?>
      <?php echo form_hidden('user_id', $result->user_id); ?>

    <div class="row">
       <div class="col-lg-3">
          <legend><b> Details</b></legend><hr>

           <div class="list-group">
              <a href="" class="list-group-item"  style="width:70%; height: 150px;">
                 <img src="<?php echo base_url('assets/dist/img/avatar_admin.png')?>" alt="" style="width:100%; height:100%;"/>
              </a> <br/>
             
             <br>
         <ul class="nav nav-pills nav-sidebar flex-column " data-widget="treeview" >
              
             <li class="nav-item has-treeview nav-link" style="background-color: black; color: white;">
                <?php echo anchor("SDashboard/adminPersonalDetail_S/{$result->user_id}","Personal Details"); ?>
             </li>
             <li class="nav-item nav-link ">
               <?php echo anchor("SDashboard/adminContactDetail_S/{$result->user_id}","Contact Details"); ?>
             </li>
           
           </ul>
         </div>
       </div>
       <div class="col-lg-9">
          <legend><b>Personal Details</b></legend><hr>
           <div class="row">
<div class="container"style="">
<?php echo form_open("admin/insertadmin");?>
  <fieldset >
      <?php if( $error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-6">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>  
            </div>
       </div>
      </div>
      <?php endif; ?><br>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">First Name :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'first_name','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('first_name')])?>

             </div>
          </div>
        </div>
      </div>
       <div class="col-lg-6">
          <?php echo form_error('first_name','<div class="text-danger">','</div>');?>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Last Name :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'last_name','class'=>'form-control', 'placeholder'=>' Last Name','value'=>set_value('last_name')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
          <?php echo form_error('last_name','<div class="text-danger">','</div>');?>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Email address :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'username','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('username')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
          <?php echo form_error('username','<div class="text-danger">','</div>');?>
      </div>
      <div class="container">
        <div class="col-lg-8">
          <div class="form-group">
            <label for="inputEmail" class="col-lg-4 control-label">Role : </label>
          </div>
          <div class="col-lg-8">
            <select class="form-control" name="user_role_id">
              <option>Select</option>
              <option value="1">Admin</option>
              <option value="2">super admin</option>
            </select>
          </div>
        </div>
      </div><br>
      <div class="col-lg-6">
          <?php echo form_error('user_role_id','<div class="text-danger">','</div>');?>
      </div>
       <div class="container">
        <div class="col-lg-8">
          <div class="form-group">
            <label for="inputEmail" class="col-lg-4 control-label">Gender : </label>
          </div>
          <div class="col-lg-8">
            <select class="form-control" name="gender">
              <option>Select</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
        </div>
      </div><br>
      <div class="col-lg-8">
        <?php echo form_error('gender','<div class="text-danger">','<div>');?>
      </div>
     <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Nationality :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'nationality','class'=>'form-control', 'placeholder'=>' Nationality','value'=>set_value('nationality')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
          <?php echo form_error('nationality','<div class="text-danger">','</div>');?>
      </div>
      <div class="container">
        <div class="col-lg-8">
          <div class="form-group">
            <label for="inputEmail" class="col-lg-4 control-label">Marital Status : </label>
          </div>
          <div class="col-lg-8">
            <select class="form-control" name="marrige_status">
              <option>Select</option>
              <option value="Single">Single</option>
              <option value="Married">Married</option>
              <option value="Unmarried">Unmarried</option>
            </select>
          </div>
        </div>
      </div><br>
       <div class="col-lg-6">
          <?php echo form_error('Married status','<div class="text-danger">','</div>');?>
      </div>
        <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Date Of Birth :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'dob','class'=>'form-control','placeholder'=>'yyyy-mm-dd','value'=>set_value('dob')])?>
            </div>
          </div>
        </div>
      </div>
      <div class="container col-lg-10">
          <?php echo form_submit(['value' =>'Submit','class'=>'btn btn-primary'])?>
          <?php echo form_reset(['value' => 'next','class'=>'btn btn-secondary'])?>
<!--
       <button type="reset" class="btn btn-secondary">Reset</button>
       <button type="submit" class="btn btn-primary">Submit</button>
-->
      </div><br><br>

  </fieldset>
<?php echo form_close();?>
</div>
</div>
       </div>
    </div>
  </div>


</div>
</div>
  </section>    
     </section>      
  </div>
  <script type="text/javascript">
    $("#form-control").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
</script> 
</body>
</html>