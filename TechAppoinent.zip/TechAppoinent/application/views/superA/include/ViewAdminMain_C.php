
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body>

 <?php echo form_open("SDashboard/ViewAdmic_C");?>
   <div class="content-wrapper"> 
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Admin Contact</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">Contact</li>
              <li class="breadcrumb-item">View User</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

  
     <section class="col-lg-12 connectedSortable"> 
      <div class="col-md-12">
            <!-- Widget: user widget style 1 -->
            <div class="card card-widget widget-user">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header text-white"
                   style="background: url('<?php echo base_url();?>assets/dist/img/photo1.png') center center;">
                <h3 class="widget-user-username text-right">Admin</h3>
                <h5 class="widget-user-desc text-right">MArketin</h5>
              </div>
              <div class="widget-user-image" style="float: center; margin-top: -10px;">
                <img class="img-circle" src="<?php echo base_url();?>assets/dist/img/1.jpg" alt="User Avatar">
                <input type="file" class="img-circle" style="width: 10px; height: 30px;">
                 <span class="fas fa-envelope"></span>
              </div>
<!--  -->
            </div>
            <!-- /.widget-user -->
          </div>
      </section><br>
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
            <div class="card">
              <div class="card-header border-0">
                <div class="d-flex justify-content-between">
                  <h3 class="card-title"><b>Peronal Detail</b></h3>
                  <button type="button"
                          class="btn btn-primary btn-sm"
                          data-card-widget="collapse"
                          data-toggle="tooltip"
                          title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                </div><br><hr>
                 <div class="container">
        <div class="col-lg-8">
      <?php if(count($result)): ?>  
        <?php foreach($result as $res):?>
          <div class="input-group mb-3">
            <input type="text" value="<?php echo $res->first_name;?>" class="form-control"/>
          </div>
          <div class="input-group mb-3">
            <input type="text" value="<?php echo $res->last_name;?>" class="form-control"/>
          </div>
         <div class="input-group mb-3">
            <input type="text" value="<?php echo $res->username;?>" class="form-control"/>
        </div>
        <div class="input-group mb-3">
            <input type="text" value="<?php echo $res->nationality;?>" class="form-control"/>
          </div>
          <div class="input-group mb-3">
            <input type="text" value="<?php echo $res->designation;?>" class="form-control"/>
          </div>
          <div class="input-group mb-3">
            <input type="text" value="<?php echo $res->company;?>" class="form-control"/>
          </div>
        </div>
       </div>
        <?php endforeach; ?>
        <?php endif; ?>
              </div>
            </div>
          </div>
    
          <div class="col-lg-6">
            <div class="card">
              <div class="card-header border-0">
                <div class="d-flex justify-content-between">
                  <h3 class="card-title"><b>Contact Details<b></h3>
                  <div class="card-tools">
                  <button type="button"
                          class="btn btn-primary btn-sm"
                          data-card-widget="collapse"
                          data-toggle="tooltip"
                          title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                </div>
                </div><br><hr>
                 <div class="col-lg-8">  
                      <div class="input-group mb-3">
                       <input type="text" value="<?php echo $res->mobile;?>" class="form-control"/>
                       </div>

                      <div class="input-group mb-3">
                        <input type="text" value="<?php echo $res->address;?>" class="form-control"/>
                       </div>
                        <div class="input-group mb-3">
                         <input type="text" value="<?php echo $res->work_loca;?>" class="form-control"/>
                       </div>
                  </div>
                 </div>
               </div>

              </div>
            </div>
          </div> 
  
  </div>
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
 <script src="<?php echo base_url('');?>assets/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url('');?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url('');?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url('');?>assets/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url('');?>assets/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?php echo base_url('');?>assets/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url('');?>assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url('');?>assets/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url('');?>assets/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url('');?>assets/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url('');?>assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url('');?>assets/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url('');?>assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('');?>assets/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url('');?>assets/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('');?>assets/dist/js/demo.js"></script >  
</body>
</html>