
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('');?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body>

   <div class="content-wrapper"> 
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">CONtact Detail</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">View Admin</li>
              <li class="breadcrumb-item">Admin Detail</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <?php echo form_open_multipart("SDashboard/addContact_detail/{$result->user_id}"); ?>
      <?php echo form_hidden('user_id', $result->user_id); ?>
     <section class="col-lg-12 connectedSortable"> 
           <div class="row">
       <div class="col-lg-3">
          <legend><b> Details</b></legend><hr>

           <div class="list-group">
              <a href="" class="list-group-item"  style=" width:70%; height: 150px;">
                 <img src="<?php echo base_url('assets/dist/img/avatar_admin.png')?>" alt="" style="width:100%; height:100%;"/>
              </a> <br/>
             
             <br>
            <ul class="nav nav-pills flex-column">
             <li class="nav-item nav-link ">
                <?php echo anchor("SDashboard/adminPersonalDetail_S/{$result->user_id}","Personal Details"); ?>
             </li>
             <li class="nav-item nav-link active" style="background-color: black;">
               <?php echo anchor("SDashboard/adminContactDetail_S/{$result->user_id}","Contact Details"); ?>
             </li>
           <!--   <li class="nav-item nav-link">
                <?php// echo anchor("Admin/adminPersonalDetail/{$result->user_id}","Qualification Details"); ?>
             </li> -->
           </ul>
         </div>
       </div>
       <div class="col-lg-9">
          <legend><b>Personal Details</b></legend><hr>
           <div class="row">
<div class="container"style="">
<?php echo form_open("admin/insertadmin");?>
  <fieldset>
      <?php if( $error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-6">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>  
            </div>
       </div>
      </div>
      <?php endif; ?><br>
    <!-- form open -->

        <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Designation :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'designation','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('designation')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Company Name :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'company','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('company')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Work Experience :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'Work_ex','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('Work_ex')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Mobile Number :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'mobile','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('mobile')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Phone Number :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'phone','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('phone')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Address :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'address','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('address')])?>
             </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="col-lg-8">
         <div class="form-group">
          <label for="exampleInputEmail1">Work Location :</label>
            <div class="col-lg-8">
             <?php echo form_input(['name' => 'work_loca','class'=>'form-control', 'placeholder'=>' First Name','value'=>set_value('work_loca')])?>
             </div>
          </div>
        </div>
      </div>
     <!-- form close -->
      <div class="container col-lg-10">
          <?php echo form_submit(['value' =>'Submit','class'=>'btn btn-primary'])?>
          <?php echo form_reset(['value' => 'Reset','class'=>'btn btn-secondary'])?>
<!--
       <button type="reset" class="btn btn-secondary">Reset</button>
       <button type="submit" class="btn btn-primary">Submit</button>
-->
      </div><br><br>

  </fieldset>
<?php echo form_close();?>
       </div>
    </div>
  </div>


</div>
</div>
  </section>    
     </section>      
  </div>
  <script type="text/javascript">
    $("#form-control").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
</script> 
</body>
</html>